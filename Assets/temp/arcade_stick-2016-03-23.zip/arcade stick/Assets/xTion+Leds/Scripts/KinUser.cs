

public class KinUser {
	
	public int id = -1;
	public float x = -1;
	public float y = -1;
	public float dist = 0.0f;
		
}

public class AllUsers {
	
	public KinUser[] users;
	
}

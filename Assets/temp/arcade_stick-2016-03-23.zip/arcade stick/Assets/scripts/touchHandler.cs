﻿using UnityEngine;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;

public static class TouchPhaseExtension
{
	public static bool isDone(this TouchPhase tPhase)
	{
		return (tPhase == TouchPhase.Ended || tPhase == TouchPhase.Canceled);
	}

	public static object getAction(this Touch t){
		return touchHandler.touches[t.fingerId].action;
	}

	public static touchInstance[] getExtended(this Touch[] touches){
		return touchHandler.touches.ToArray();
	}

	public static touchInstance getExtended(this Touch[] touch, int id){
		return touchHandler.touches[id];
	}
}



public class touchInstance {
	
	public Touch tObj;
	public int fingerId;
	public int tapCount = 0;
	public float startTime;
	public float pressTime;
	public float distanceTraveled;
	public float totalMagnitude; //(startPos - currentPos).magnitude
	public float pinchDistance; //distance of pinch since beginning
	public float pinchRatio; //distance / pinchStartDistance

	public Vector2 startPos;
	public Vector2 currentPos;
	public TouchPhase phase;

	private float tapTimer;
	private float pinchStartDistance;
	private Vector2[] pinchPos = new Vector2[2];


	public actions action;
	public actions overrideAction;
	public directions swipeDirection;
	public enum actions{None, Down, LongPress, Tap, Swipe, Drag, Pinch}; 
	public enum directions{None, Up, Down, Left, Right};
	
	public touchInstance(){}
	public touchInstance(Touch t){
		tObj = t;
		fingerId = t.fingerId;
		startPos = tObj.position;
		startTime = Time.time;
		action = actions.Down;
		overrideAction = actions.None;

	}

	private directions getSwipeDirection(){
		Vector2 direction = tObj.position - startPos;
		if (Mathf.Abs (direction.x) > Mathf.Abs(direction.y)){
			if (direction.x < 0)
				return directions.Left;
			else
				return directions.Right;
		}else{
			if (direction.y < 0)
				return directions.Down;
			else
				return directions.Up;
		}
		return directions.None;

	}

	private bool noneOrDown(){
		return (action == actions.None || action == actions.Down);
	}


	public void Update(Touch t){
		float currentMagnitude = 0f;
		bool emergencyEnd = false;

		if (fingerId < touchHandler.touchCount){
			tObj = t;
			phase = tObj.phase;
			currentPos = tObj.position;
			currentMagnitude = tObj.deltaPosition.magnitude;
			totalMagnitude = Vector2.Distance(startPos, currentPos);
		}else{
			emergencyEnd = true;
		}
		/* !!! isDone() -> extension method (phase == canceled || ended) !!! */
		if (tObj.phase.isDone() || emergencyEnd){

			tapTimer += Time.deltaTime;
			if (tapTimer > touchHandler._tapInterval){
				touchHandler.touches.Remove (this);}
			if (pressTime < touchHandler._tapInterval && action == actions.Down){
				action = actions.Tap;}
		}else{
			pressTime += Time.deltaTime;
		}

		if (currentMagnitude > touchHandler._dragThreshold)
			distanceTraveled += currentMagnitude;

		if (tObj.phase == TouchPhase.Began){
			tapCount++;
			tapTimer = 0f;
		}
		//ACTIONS
		if (overrideAction != actions.None){
			action = overrideAction;
		}else if(noneOrDown()){
			//LongPress
			if (totalMagnitude < touchHandler._dragThreshold &&
			    pressTime >= touchHandler._longPressTime){
				action = actions.LongPress;
			}
			//Swipe
			if (distanceTraveled > 0f && pressTime < touchHandler._swipeSensitivity && tObj.phase.isDone()){
				action = actions.Swipe;
				swipeDirection = getSwipeDirection();
			}
			//Pinch
			if (fingerId == 1 && action != actions.Swipe && touchHandler.touchCount > 1){
				action = actions.Pinch;
				pinchPos[0] = touchHandler.touches[0].tObj.position;
				pinchPos[1] = tObj.position;
				pinchStartDistance = Vector2.Distance(pinchPos[0], pinchPos[1]);
				pinchDistance = 0f;
				pinchRatio = 1f;
			}
		}else if (action == actions.Pinch){
			if (touchHandler.touchCount > 1){
				pinchPos[0] = touchHandler.touches[0].tObj.position;
				pinchPos[1] = tObj.position;
				float dist = Vector2.Distance(pinchPos[0], pinchPos[1]);

				pinchDistance = dist - pinchStartDistance;
				pinchRatio = dist / pinchStartDistance;
			}
		}

		
	}

}

[DisallowMultipleComponent]
public class touchHandler : MonoBehaviour{

	public bool simulateTouch = false;
	public static int touchCount = 0;
	public TouchCreator tc = new TouchCreator();
	private Touch fakeTouch;

	[Tooltip("Time allowed between taps before reset")]
	public float tapInterval = 0.15f;
	[Range(0.01f, 1f)] public float longPressTime = 0.5f;
	[Tooltip("Based on deltaposition.magnitude")]
	[Range(1f, 150f)] public float dragThreshold = 30f;
	[Range(0.01f, 1f)] public float swipeSensitivity = 0.1f;

	public static List<touchInstance> touches = new List<touchInstance>();

	public static float _tapInterval;
	public static float _longPressTime;

	public static float _dragThreshold;
	public static float _swipeSensitivity;

	// Use this for initialization
	void Start () {
		_tapInterval = tapInterval;
		_longPressTime = longPressTime;
		_dragThreshold = dragThreshold;
		_swipeSensitivity = swipeSensitivity;
		fakeTouch = tc.CreateEmpty();
	}

	// Update is called once per frame
	void Update () {

		foreach(Touch t in Input.touches){
			//use the following line if fingerId v touches.Count proves unreliable
			if (!touches.Exists ( x => x.fingerId == t.fingerId )){
				touches.Add (new touchInstance(t));
			}
		}

		//simulate touch with mouse
		touchCount = touches.Count;
		if (simulateTouch){ 
			if(Input.GetMouseButtonDown(0)){
				fakeTouch = tc.Begin ();
				if (!touches.Exists ( x => x.fingerId == 0 )){
					touches.Add (new touchInstance(fakeTouch));
				}
			}else if (Input.GetMouseButton(0)){
				fakeTouch = tc.Update ();
			}else if (Input.GetMouseButtonUp(0)){
				fakeTouch = tc.End();
			}else{
				fakeTouch = tc.CreateEmpty ();
			}

		}

		touchCount = touches.Count;
		if (touchCount > 0){
			for(int t = 0; t < touchCount; t++){
				if (simulateTouch && t == 0){
					touches[0].Update (fakeTouch);
				} else {
					touches[t].Update (Input.GetTouch (t));
				}
			}
		}
		touchCount = touches.Count;
		
	}

	void OnGUI()
	{
		Color fontColor = Color.white;
		int w = Screen.width, h = Screen.height;
		
		GUIStyle style = new GUIStyle();

		Rect rect = new Rect(0, 100, w, h * 2 / 100);
		style.alignment = TextAnchor.UpperLeft;
		style.fontSize = h * 2 / 75;
		style.normal.textColor = fontColor;
		string text = "";
		if (touches.Count > 0){
			text += string.Format("{0}\n{1}", touches[0].phase, touches[0].action);
			text += string.Format("\n {0}", touches[0].tapCount);
			text += string.Format("\n {0}", touches[0].totalMagnitude);
			text += string.Format("\n {0} - {1}", touches[0].startPos, touches[0].currentPos);

		}
		GUI.Label(rect, text, style);
	}


	public static bool isPinching(){
		if (touches.Count > 1)
			return (touches[1].action == touchInstance.actions.Pinch);
		return false;
	}

	public static float pinchDistance(){
		if (touches.Count > 1)
			return touches[1].pinchDistance;
		return 0;
	}

	public static float pinchRatio(){
		if (touches.Count > 1)
			return touches[1].pinchRatio;
		return 1;
	}

}
